# IA Daily Value Digest — Agent
Monitora diariamente notícias/artigos e captura **exemplos de uso real de IA em empresas com geração de valor mensurável** (R$/$, %, horas, ROI, etc.).
Armazena em SQLite e gera um **relatório diário** em Markdown. Opcional: envia por e‑mail.

## Visão geral
- **Coleta:** RSS (rápido e estável). Você pode adicionar Web Search/API depois.
- **Extração:** baixa a página, limpa HTML e extrai *sinais de valor* (regex simples).
- **Classificação:** marca como **mensurável** se houver pelo menos um número relevante (R$/$, %, horas, ROI, \$ milhões, etc.).
- **Armazenamento:** `data/ia_digest.db` (SQLite).
- **Relatório:** `out/digest-YYYY-MM-DD.md` (com itens deduplicados e sumarizados).
- **Envio opcional por e‑mail:** via SMTP (Gmail / outro).

## Como rodar
1) Python 3.10+
2) `pip install -r requirements.txt`
3) Copie `.env.example` para `.env` e preencha o que desejar (opcional para e‑mail).
4) Edite `src/sources.yaml` com seus feeds e palavras‑chave.
5) Execute:
```bash
python -m src.main
```
O relatório do dia aparece em `out/`.

## Agendamento
### Linux/macOS (cron)
```cron
# Todos os dias às 08:30
30 8 * * * /usr/bin/env bash -lc 'cd /mnt/data/ia-digest-agent && /usr/bin/python -m src.main >> logs/cron.log 2>&1'
```

### GitHub Actions (alternativo)
- Crie um repositório privado.
- Adicione os arquivos deste projeto.
- Use um workflow com `schedule:` (ex.: `cron: "30 11 * * *"`).

## Personalização rápida
- **Keywords**: em `sources.yaml` (campo `must_include`/`must_exclude`).
- **Regras de extração**: em `src/extractors/value_signals.py`.
- **Limiar de classificação**: em `src/extractors/value_signals.py` (`is_measurable`).

## Limitações e próximos passos
- RSS não cobre tudo. Para ampliar: Google Alerts, Bing Web Search, Perigon/NewsAPI, GDELT (exigem API).
- Páginas com paywall podem falhar.
- Para PT‑BR, já há padrões para `R$`, `milhões`, `economia de`, etc.

---
Feito para a Beatriz, Recife (UTC‑3). Data de geração: 2025-10-24.
