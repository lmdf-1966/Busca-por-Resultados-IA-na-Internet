
import requests, re
from bs4 import BeautifulSoup

HEADERS = {"User-Agent": "Mozilla/5.0 (IA-Digest-Agent)"}

def clean_text(text: str) -> str:
    text = re.sub(r"\s+", " ", text or " ").strip()
    return text

def fetch_and_extract(url: str, timeout: int = 15) -> str:
    try:
        r = requests.get(url, headers=HEADERS, timeout=timeout)
        r.raise_for_status()
        html = r.text
        soup = BeautifulSoup(html, "html.parser")
        # Remove common noise
        for junk in soup(["script", "style", "noscript", "aside", "footer", "nav", "form"]):
            junk.decompose()
        # Heuristic: get article text
        candidates = soup.find_all(["article", "main"]) or [soup.body or soup]
        parts = []
        for c in candidates:
            for p in c.find_all(["p", "li"]):
                txt = p.get_text(separator=" ", strip=True)
                if txt and len(txt.split()) > 5:
                    parts.append(txt)
        if not parts:
            # fallback: all paragraphs
            for p in soup.find_all("p"):
                txt = p.get_text(separator=" ", strip=True)
                if txt and len(txt.split()) > 5:
                    parts.append(txt)
        return clean_text(" ".join(parts)[:20000])  # cap
    except Exception:
        return ""
